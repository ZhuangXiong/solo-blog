title: ' 基数排序（Radix Sort）'
date: '2019-09-18 23:49:55'
updated: '2019-09-18 23:58:23'
tags: [算法, java]
permalink: /articles/2019/09/18/1568821795187.html
---
## 基数排序（Radix Sort）

> 数组中的数字根据各个位数进行比较排序

### 举例数组为（230、112、28、19、20、35）

#### 第一轮进行个位数的排序

| 数字 | 列1 | 列2 |
| --- | --- | --- |
| 0| 230| 20|
| 1| | |
| 2| 112| |
| 3| | |
| 4| | |
| 5| 35| |
| 6| | |
| 7| | |
| 8| 28| |
| 9| 19| |

> 取出排序结果（230、20、112、35、28、19）

#### 第二轮进行十位数的排序

| 数字 | 列1 | 列2 |列3|
| --- | --- | --- | --- |
| 0| 112| 19 | |
| 1| | | |
| 2| 230| 20|28|
| 3| 35| | |
| 4| | | |
| 5| | | |
| 6| | | |
| 7| | | |
| 8| | | |
| 9| | | |

> 取出排序结果（112、19、230、20、28、35）

#### 第三轮进行百位数的排序

| 数字 | 列1 | 列2 |列3|列4|
| --- | --- | --- | --- |---|
| 0| 19| 20|28|35|
| 1| 112| | | |
| 2| 230| | | |
| 3| | | | |
| 4| | | | |
| 5| | | | |
| 6| | | | |
| 7| | | | |
| 8| | | | |
| 9| | | | |

> 取出排序结果（19、20、28、35、112、230）

### 构造算法步骤分解

1. 先算要有几轮排序

2. 使用临时排序数组，存储每轮排序

3. 排序后的临时数组进入下一轮的排序，直到排序轮次全部结束

```

/**

* 找出最大数

* @param datas 数据

* @return

*/

private int getMaxValues(int[] datas){

		int max = 0;

		for(int value : datas){

			if(value > max){

					max = value;

			}

		}

		return max;

}

/**

* 排序

* @param datas 数据

*/

private int[] sort(int[] datas){

	int max = getMaxValues(datas);

	for(int digit = 1;max/digit >0;digit=digit*10){

		int[][] buckets = new int[datas.length][10];

		for (int i = 0; i<datas.length;i++){

			int number = (datas[i]/digit)%10;

			buckets[i][number] = datas[digit];

		}

		int index = 0;

		//数据回收

		for(int i = 0; i <10;i++){

			for(int j = 0;j< datas.length;j++){

				if(buckets[j][i] != 0){

				datas[index++] = buckets[j][i];

				}

			}

		}

	}

	return datas;

}

```

